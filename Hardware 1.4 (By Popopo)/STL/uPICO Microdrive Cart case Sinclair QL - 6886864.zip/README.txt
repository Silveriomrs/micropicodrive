uPICO Microdrive Cart case Sinclair QL by Jbizze on Thingiverse: https://www.thingiverse.com/thing:6886864

Summary:
A case for this project....https://qlforum.co.uk/viewtopic.php?p=60890#p60890